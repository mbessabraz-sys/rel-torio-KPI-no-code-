# KPI Intelligence Dashboard

Dashboard interativo de KPIs criado para portfólio de Dados, BI e Inteligência Artificial.

## O que o projeto demonstra

- KPI cards executivos
- Evolução temporal de receita
- Distribuição por área
- Funil de conversão
- Radar de eficiência
- Filtros de período e área
- Exportação dos dados em CSV
- Layout responsivo
- Design corporativo para portfólio

## Como usar

1. Abra `index.html` no navegador.
2. Para publicar no GitHub, crie um repositório e envie o arquivo.
3. Ative **Settings → Pages** e selecione a branch principal.
4. Para trocar os dados, edite o objeto `datasets` no JavaScript.

## Stack

HTML • CSS • JavaScript • Chart.js

## Observação

Os números atuais são demonstrativos. Substitua-os pelos dados reais do seu projeto para transformar o dashboard em um case de portfólio.
